<?php

//Incluímos inicialmente la conexión a la base de datos
require '../config/conexion.php';

Class Servicio
{
    //Implementamoa nuestro constructor
    public function __construct(){

    }

    //Implementamos un método para insertar registros
    public function insertar($idproveedor, $idusuario, $tipo_comprobante, $serie_comprobante, $num_comprobante, $fecha_hora, $fecha_ven,$impuesto, $total_compra, $estado, $cantidad, $concepto, $precio){
        $sql = "INSERT INTO servicio (idproveedor, idusuario, tipo_comprobante, serie_comprobante, num_comprobante, fecha_hora, fecha_ven, impuesto, total_compra, estado) 
                VALUES ('$idproveedor', '$idusuario', '$tipo_comprobante', '$serie_comprobante', '$num_comprobante', '$fecha_hora', '$fecha_ven', '$impuesto', '$total_compra', '$estado')";

        $idservicioNew = ejecutarConsulta_retornarID($sql);                
        
        $num_elementos = 0;
        $sw = true;

        while ($num_elementos < count($concepto)) { //prueba aqui si hay algun error.
            $sql_detalle = "INSERT INTO serviciodetalle(idservicio, cantidad, concepto, precio)
                            VALUES ('$idservicioNew', '$cantidad[$num_elementos]', '$concepto[$num_elementos]', '$precio[$num_elementos]')";

            ejecutarConsulta($sql_detalle) or $sw = false;
            $num_elementos = $num_elementos + 1;
        }

        return $sw;
    }

    //Implementamos un método para anular
    public function anular($idservicio){
        $sql = "UPDATE servicio SET estado='Anulado' WHERE idservicio='$idservicio'";
        return ejecutarConsulta($sql);
    }

    //Implementamos un método para listar un registro
    public function mostrar($idservicio){
        $sql = "SELECT s.idservicio, DATE(s.fecha_hora) as fecha, DATE(s.fecha_ven) as fecha_v, s.idproveedor, p.nombre as proveedor, 
                    u.idusuario, u.nombre as usuario, s.tipo_comprobante, s.serie_comprobante, s.num_comprobante,    
                    s.total_compra, s.impuesto, s.estado
                FROM servicio s
                INNER JOIN persona p ON s.idproveedor = p.idpersona 
                INNER JOIN usuario u ON s.idusuario = u.idusuario
                WHERE idservicio='$idservicio'";
        return ejecutarConsultaSimpleFila($sql);
    }

    public function listarDetalle($idservicio){
        $sql = "SELECT idservicio, cantidad, concepto, precio FROM serviciodetalle
                WHERE idservicio = '$idservicio'";
        return ejecutarConsulta($sql);
    }

    //Implementar para listar todos los registros
    public function listar(){
        $sql = "SELECT s.idservicio, DATE(s.fecha_hora) as fecha, DATE(s.fecha_ven) as fecha_v, s.idproveedor, p.nombre as proveedor, 
                    u.idusuario, u.nombre as usuario, s.tipo_comprobante, s.serie_comprobante, s.num_comprobante,    
                    s.total_compra, s.impuesto, s.estado
                FROM servicio s
                INNER JOIN persona p ON s.idproveedor = p.idpersona 
                INNER JOIN usuario u ON s.idusuario = u.idusuario
                ORDER BY s.idservicio DESC";
        return ejecutarConsulta($sql);
    }
}


?>