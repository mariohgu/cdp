var tabla;

function init() {
    listar();
    $('#fecha_inicio').change(listar);
    $('#fecha_fin').change(listar);
}

//function listar
function listar() {
    var fecha_inicio = $('#fecha_inicio').val();
    var fecha_fin = $('#fecha_fin').val();

    $.ajax({
        url: '../ajax/consultas.php?op=comprasfecha',
        type: 'GET',
        dataType: 'json',
        
        data: { fecha_inicio: fecha_inicio, fecha_fin: fecha_fin },
        success: function (response) {
            tabla = $('#tblListado').DataTable({
                'aProcessing': true, //activamos el procesamiento del datatable
                'aServerSide': true, //paginaci��n y filtrado realizados por el servidor
                dom: 'Bfrtip', //definimos los elementos del control de tabla
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdf'
                ],              
                
                'data': response.aaData,
                'columns': [
                    { 'data': '0' },
                    { 'data': '1' },
                    { 'data': '2' },
                    { 'data': '3' },
                    { 'data': '4' },
                    { 'data': '5' },
                    { 'data': '6' },
                    { 'data': '7' }
                ],
                'destroy': true,
                
            });

            $('#deuda').text(response.deuda);
            console.log(response.deuda);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

//function listar
//function MostrarTotal() {
//    $('#deuda').text(results.deuda);
//}



init();



