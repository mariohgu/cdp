var tabla;

function init() {
    listar();
    $('#fecha_inicio').change(listar);
    $('#fecha_fin').change(listar);
}

function listar() {
    var fecha_inicio = $('#fecha_inicio').val();
    var fecha_fin = $('#fecha_fin').val();
    $.ajax({
        url: '../ajax/consultas.php?op=consultapago',
        type: 'GET',
        dataType: 'json',
        data: { fecha_inicio: fecha_inicio, fecha_fin: fecha_fin },
        success: function (response) {
            tabla = $('#tblListado').DataTable({
                'aProcessing': true,
                'aServerSide': true,
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdf'
                ],              
                'data': response.aaData,
                'columns': [
                    { 'data': '0' },
                    { 'data': '1' },
                    { 'data': '2' },
                    { 'data': '3' },
                    { 'data': '4' },
                    { 'data': '5' },
                    { 'data': '6' },
                    { 'data': '7' }
                ],
                'destroy': true,
            });
            $('#deuda').text(response.deudas);
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
    });
}

/*
Esta es la que estaba dentro del codigo y se podia actualizar la tabla desde compraPagada

function listar() {
    var fecha_inicio = $('#fecha_inicio').val();
    var fecha_fin = $('#fecha_fin').val();

    tabla = $('#tblListado').dataTable({
        'aProcessing': true, //activamos el procesamiento del datatable
        'aServerSide': true, //paginaci��n y filtrado realizados por el servidor
        dom: 'Bfrtip', //definimos los elementos del control de tabla
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdf'
        ],
        'ajax': {
            url: '../ajax/consultas.php?op=consultapago',
            data: {fecha_inicio: fecha_inicio, fecha_fin: fecha_fin},
            type: 'get',
            dataType: 'json',
            error: function e() {
                console.log(e.responseText);
            }},
        'bDestroy': true,
        'iDisplayLength': 5,//paginaci��n
        'order': [[0, 'desc']] //ordenar (columns, orden)
    }).DataTable();
}

*/

function compraPagada(idingreso) {
    bootbox.confirm('¿Está seguro de registrar como pagada la compra?', function(result){
        if(result){
            $.post('../ajax/consultas.php?op=compraPagada', {idingreso: idingreso}, function(e){
                bootbox.alert(e);
                location.reload();
                //tabla.ajax.reload();
            });
        }
    });
}

function servicioPagado(idservicio) {
    bootbox.confirm('¿Está seguro de registrar como pagado el servicio?', function(result){
        if(result){
            $.post('../ajax/consultas.php?op=servicioPagado', {idservicio: idservicio}, function(e){
                bootbox.alert(e);
                location.reload();
                //tabla.ajax.reload();
            });
        }
    });
}

init();
