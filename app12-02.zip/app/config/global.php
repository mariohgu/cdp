<?php

//ip de la pc del servidor de la base de datos
define("DB_HOST", "localhost");

//Nombre de la base de datos
define("DB_NAME", "dialisi1_dbsistema");

//Usuario de la base de datos
define("DB_USERNAME","dialisi1_peru");

//Contrase�0�9a del usuario de la ase de datos
define("DB_PASSWORD","d14l1s1s123");

//Definimos la codificaci��n de los caracteres
define("DB_ENCODE","utf8");

//Definimos una constante como nombre del proyecto
define("PRO_NOMBRE","ITVentas");

?>