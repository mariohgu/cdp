<?php

require_once '../models/Consultas.php';

$consulta = new Consultas();

switch ($_GET["op"]) {
    case 'comprasfecha':
        try {
            $fecha_inicio = $_REQUEST['fecha_inicio'];
            $fecha_fin = $_REQUEST['fecha_fin'];
            $deuda = 0.00;

            $rspta = $consulta->comprasFecha($fecha_inicio, $fecha_fin);

            $data = Array();

            while ($reg = $rspta->fetch_object()) {
                
                $data[] = array(
                    "0"=>$reg->fecha,
                    "1"=>$reg->usuario,
                    "2"=>$reg->proveedor,
                    "3"=>$reg->tipo_comprobante,
                    "4"=>$reg->serie_comprobante . ' - ' . $reg->num_comprobante,
                    "5"=>$reg->total_compra,
                    "6"=>$reg->tipo,
                    "7"=>($reg->estado == 'Aceptado') ? '<span class="label bg-green">Cancelado</span>' : (($reg->estado == 'Pagar') ? '<span class="label bg-yellow">PAGAR</span>'  :'<span class="label bg-red">Anulado</span>')
                );
                $deuda = $deuda + ($reg->total_compra);
                $deuda = round($deuda,2);
                
            }
            
            // Creamos un arreglo asociativo para enviar la respuesta de AJAX

            $response = array(
                "sEcho"=>1, //informaci��n para el datatables
                "iTotalRecords"=>count($data), //enviamos el total de registros al datatable
                "iTotalDisplayRecords"=>count($data), //enviamos el total de registro a visualizar
                "deuda" => $deuda,
                "aaData"=>$data
                
            );
            
            echo json_encode($response);
        } catch (Exception $e) {
            echo 'Excepci��n capturada: ',  $e->getMessage(), "\n";
        }        

        break;
    case 'compraPagada':
        $idingreso = $_REQUEST['idingreso'];
        $rspta = $consulta->compraPagada($idingreso);
        //echo "este es '$idingreso' se ";
        echo $rspta ? "Se cambio el registro" : "Error en cambio";
        break;
    case 'servicioPagado':
        $idservicio = $_REQUEST['idservicio'];
        $rspta = $consulta->servicioPagado($idservicio);
        //echo "este es '$idservicio' se ";
        echo $rspta ? "Se cambio el registro" : "Error en cambio";
        break;    
    case 'ventasFechaCliente':
        try {
            $fecha_inicio = $_REQUEST['fecha_inicio'];
            $fecha_fin = $_REQUEST['fecha_fin'];
            $idcliente = $_REQUEST['idcliente'];

            $rspta = $consulta->ventasFechaCliente($fecha_inicio, $fecha_fin, $idcliente);

            $data = Array();

            while ($reg = $rspta->fetch_object()) {
                $data[] = array(
                    "0"=>$reg->fecha,
                    "1"=>$reg->cliente,
                    "2"=>$reg->articulo,
                    "3"=>$reg->cantidad,
                    "4"=>($reg->estado) ? '<span class="label bg-green">Activado</span>' : '<span class="label bg-red">Desactivado</span>'
                );
            }

            $results = array(
                "sEcho"=>1, //informaci��n para el datatables
                "iTotalRecords"=>count($data), //enviamos el total de registros al datatable
                "iTotalDisplayRecords"=>count($data), //enviamos el total de registro a visualizar
                "aaData"=>$data
            );

            echo json_encode($results);
        } catch (Exception $e) {
            echo 'Excepci��n capturada: ',  $e->getMessage(), "\n";
        }        

        break;
    case 'consultapago':
        
            $fecha_inicio = $_REQUEST['fecha_inicio'];
            $fecha_fin = $_REQUEST['fecha_fin'];
            $deuda2 = 0.00;

            $rspta = $consulta->pagoFecha($fecha_inicio, $fecha_fin);

            $data = Array();

            while ($reg = $rspta->fetch_object()) {
                
                $data[] = array(
                    "0"=>($reg->tipo == 'Compra') ? '<button class="btn btn-success" onclick="compraPagada('.$reg->codigo.')"><i class="fa fa-check"></i></button> '
                    : 
                    '<button class="btn btn-success" onclick="servicioPagado('.$reg->codigo.')"><i class="fa fa-check"></i></button>',
                    "1"=>$reg->fecha,
                    "2"=>$reg->proveedor,
                    "3"=>$reg->tipo_comprobante,
                    "4"=>$reg->serie_comprobante . ' - ' . $reg->num_comprobante,
                    "5"=>$reg->total_compra,
                    "6"=>$reg->tipo,
                    "7"=>($reg->estado == 'Aceptado') ? '<span class="label bg-green">Cancelado</span>' : (($reg->estado == 'Pagar') ? '<span class="label bg-yellow">PAGAR</span>'  :'<span class="label bg-red">Anulado</span>')
                );
                $deuda2 = $deuda2 + ($reg->total_compra);
                $deuda2 = round($deuda2,2);
                
            }
            
            // Creamos un arreglo asociativo para enviar la respuesta de AJAX

            $results = array(
                "sEcho"=>1, //informaci��n para el datatables
                "iTotalRecords"=>count($data), //enviamos el total de registros al datatable
                "iTotalDisplayRecords"=>count($data), //enviamos el total de registro a visualizar
                "deudas" => $deuda2,
                "aaData"=>$data
                
            );
            
            echo json_encode($results);
               

        break;

}

?>